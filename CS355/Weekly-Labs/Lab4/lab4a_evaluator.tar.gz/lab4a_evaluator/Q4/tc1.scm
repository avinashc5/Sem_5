(define (naturals-from n)
  (cons-stream n (naturals-from (+ n 1))))
(define naturals (naturals-from 1))

(take (sliding-window naturals 3) 5)