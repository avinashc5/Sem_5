(define (naturals-from n)
  (cons-stream n (naturals-from (+ n 1))))
(define naturals (naturals-from 1))

(take (sliding-window (list->stream '(17 89 321 123 234 289)) 1) 2)