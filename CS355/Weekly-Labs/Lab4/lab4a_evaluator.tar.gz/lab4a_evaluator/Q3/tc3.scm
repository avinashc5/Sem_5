(define (naturals-from n)
  (cons-stream n (naturals-from (+ n 1))))
(define naturals (naturals-from 1))

(interleave-streams (list->stream '(1 2 3)) naturals)