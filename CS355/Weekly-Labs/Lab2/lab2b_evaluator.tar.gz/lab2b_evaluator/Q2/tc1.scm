(define p (make-rat 16 24))
(numer p)
(denom p)

(define q (make-rat 7 11))
(numer q)
(denom q)

(define s (add-rat p q))
(numer s)
(denom s)

(define m (mul-rat p q))
(numer m)
(denom m)