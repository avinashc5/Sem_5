(define p (make-rat 13 39))
(numer p)
(denom p)

(define s (add-rat p p))
(numer s)
(denom s)

(define m (mul-rat p p))
(numer m)
(denom m)

(define r (add-rat s p))
(numer r)
(denom r)