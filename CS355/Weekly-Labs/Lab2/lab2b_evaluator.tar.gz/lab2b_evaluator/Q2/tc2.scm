(define p (make-rat 2 30))
(numer p)
(denom p)

(define q (make-rat 1 11))
(numer q)
(denom q)

(define s (add-rat p q))
(numer s)
(denom s)

(define m (mul-rat p s))
(numer m)
(denom m)